package shop;

import org.junit.Test;





public class WebShopApplicationTests {

	@Test
	public void contextLoads() {
	}

}
