package com.miu.edu.shopclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopclientApplication.class, args);
	}

}
