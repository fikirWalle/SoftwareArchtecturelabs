package com.miu.edu.shopclient.model;





public class Item {


    private Product product;
    private int quantity;
}
