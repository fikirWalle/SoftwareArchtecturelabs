package com.miu.edu.shopclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
