package edu.miu.restclientdemo.model;

import lombok.Data;

@Data
public class Supplier {

    private Integer supplierId;
    private String name;
}
