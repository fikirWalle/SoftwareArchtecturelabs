package edu.miu.restclientdemo.model;

import lombok.Data;


@Data

public class Item {


    private Product product;
    private int quantity;
}
