package edu.mu.demo.model;

import lombok.Data;

@Data
public class CreditCard {
    private int creditCardNumber;
    private String provider;
}
