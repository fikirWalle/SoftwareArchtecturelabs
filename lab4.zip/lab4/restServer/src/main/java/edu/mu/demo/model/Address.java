package edu.mu.demo.model;

import lombok.Data;

@Data
public class Address {
    private String state;
    private String street;
    private String zipCode;

}
